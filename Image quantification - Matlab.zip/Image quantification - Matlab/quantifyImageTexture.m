function textureMeasures = quantifyImageTexture(image)
    I = image;
    
    if size(I, 3) == 3
        I = rgb2gray(I);
    end
    
    % Normalize the intensity values to the range 0-1
    I1 = double(I) / 255;

    % Create a Gray-Level Co-Occurrence Matrix (GLCM) and calculate texture features
    offsets = [0 1; -1 1; -1 0; -1 -1];  % Define four directions
    glcm = graycomatrix(I1, 'Offset', offsets, 'Symmetric', true);
    
    % Calculate GLCM-derived statistics
    stats = graycoprops(glcm);

    % Initialize texture measures structure
    textureMeasures = struct();
    
    % Extract features from the stats struct
    textureMeasures.Contrast = mean(stats.Contrast);
    textureMeasures.Correlation = mean(stats.Correlation);
    textureMeasures.Energy = mean(stats.Energy);
    textureMeasures.Homogeneity = mean(stats.Homogeneity);
    textureMeasures.Entropy = entropy(I1);
    textureMeasures.Std = std(I1(:));
    textureMeasures.Mean = mean(I1(:));
    textureMeasures.Range = range(I1(:));

    % %%%%%%%%%%%%%%%
    % Normalize intensity relative to the max intensity in the image
    % %%%%%%%%%%%%%%%
 
    I2 = double(I) / 255;
    I2 = I2/max(max(I2));

    % Create a Gray-Level Co-Occurrence Matrix (GLCM) and calculate texture features
    offsets = [0 1; -1 1; -1 0; -1 -1];  % Define four directions
    glcm2 = graycomatrix(I2, 'Offset', offsets, 'Symmetric', true);
    
    % Calculate GLCM-derived statistics
    stats2 = graycoprops(glcm2);
    
    % Extract features from the stats2 struct
    textureMeasures.ContrastN = mean(stats2.Contrast);
    textureMeasures.CorrelationN = mean(stats2.Correlation);
    textureMeasures.EnergyN = mean(stats2.Energy);
    textureMeasures.HomogeneityN = mean(stats2.Homogeneity);
    textureMeasures.EntropyN = entropy(I2);
    textureMeasures.StdN = std(I2(:));
    textureMeasures.MeanN = mean(I2(:));
    textureMeasures.RangeN = range(I2(:));

    % %%%%%%%%%%%%%%%
    % Binarize normalized image before texture quantification
    % %%%%%%%%%%%%%%%

    I3 = double(I) / 255;
    I3 = I2/max(max(I3));
    I3 = imbinarize(I3);

    % Create a Gray-Level Co-Occurrence Matrix (GLCM) and calculate texture features
    offsets = [0 1; -1 1; -1 0; -1 -1];  % Define four directions
    glcm2 = graycomatrix(I3, 'Offset', offsets, 'Symmetric', true);
    
    % Calculate GLCM-derived statistics
    stats3 = graycoprops(glcm2);
    
    % Extract features from the stats3 struct
    textureMeasures.ContrastNB = mean(stats3.Contrast);
    textureMeasures.CorrelationNB = mean(stats3.Correlation);
    textureMeasures.EnergyNB = mean(stats3.Energy);
    textureMeasures.HomogeneityNB = mean(stats3.Homogeneity);
    textureMeasures.EntropyNB = entropy(I3);
    textureMeasures.StdNB = std(I3(:));
    textureMeasures.MeanNB = mean(I3(:));
    textureMeasures.RangeNB = range(I3(:));
    
end


