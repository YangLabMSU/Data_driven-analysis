clear;
clc;
close all

workingDir = pwd;



folderPath = '/Users/amirostadi/Desktop/1o4 image analysis/AB_IM_Quantification/PV AB images org';
addpath('/Users/amirostadi/Desktop/1o4 image analysis/AB_IM_Quantification');

% Get the subfolders in the main folder
antibodyFolders = dir(folderPath);
antibodyFolders = antibodyFolders(3:end);

% Initialize variables to store the data
data = {};
antibodyNames = {};
doseLevels = {};
gridData = {};

% Loop over the antibody folders
for i = 1:length(antibodyFolders)
    % Get the antibody name
    antibodyName = antibodyFolders(i).name;
    antibodyNames{i} = antibodyName;
    disp(antibodyName)

        % Get the dose folders inside the antibody folder
        doseFolders = dir(fullfile(folderPath, antibodyName));
        doseFolders = doseFolders(3:end);
        
        % Loop over the dose folders 
    for j = 1:length(doseFolders)
        % Get the dose level
        doseLevel = doseFolders(j).name;
        doseLevels{j} = doseLevel;
        disp(doseLevel)
        
        % Get the tif files inside the dose folder
        imageFiles = dir(fullfile(folderPath, antibodyName, doseLevel, '*.tif'));
        
        % Loop over the image files
        for k = 1:length(imageFiles)
            % Get the image file name
            imageFileName = imageFiles(k).name;
            
            % Extract the relevant information from the image file name
            [startIdx, endIdx] = regexp(imageFileName, '(?<=_)\d+h');
            treatmentTimeStr = imageFileName(startIdx:endIdx);
            
            % Check if the treatment time is 24h or 4h
            if contains(imageFileName, '24h')
                treatmentTime = '24h';
            else
                treatmentTime = '4h';
            end
            
            if contains(imageFileName, 'F-actin')
                imagingType = 'F-actin';
            elseif contains(imageFileName, 'RhoA')
                imagingType = 'RhoA';
            elseif contains(imageFileName, 'Dsg3')
                imagingType = 'Dsg3';
            elseif contains(imageFileName, 'E-cad')
                imagingType = 'E-cad';
            elseif contains(imageFileName, 'IF')
                imagingType = 'IF';
            else
                imagingType = 'Unknown';
            end
            
            % Read the image
            imagePath = fullfile(folderPath, antibodyName, doseLevel, imageFileName);
            image = imread(imagePath);


            % Processing the entire image
        
            % Calculate the average intensity of the image
            avgIntensityEntireIm = mean(image(:));

            %%%% Processing subimages
            croppedImages = CropImage(image);
            
            % Initialize the accumulator structure with empty vectors
            CVMeasuresAccumulator = struct('CV', [], 'Iso', [], 'Aniso', [], 'Theta', [], 'ii', [], 'jj', []);

            fl = any(strcmp(imagingType, {'F-actin', 'IF'})); % fl=1 if these otherwuse zero       


            for i_l = 1:size(croppedImages, 1)
                for j_l = 1:size(croppedImages, 2)
                    if ~isempty(croppedImages{i_l, j_l}) 
                        CVMeasures = CV_func(croppedImages{i_l, j_l}, .1,.3, 16, 1, fl);
                        fieldNames = fieldnames(CVMeasures);
                        for fieldName = fieldNames'
                        fn = fieldName{1}; 
                        CVMeasuresAccumulator.(fn)(end+1) = CVMeasures.(fn);
                        end
                        CVMeasuresAccumulator.ii(end+1) = i_l;
                        CVMeasuresAccumulator.jj(end+1) = j_l;
                    end
                end
            end

        % Calculate the mean for each field of CVMeasures
            CVMeasuresMean = struct();
            for fieldName = fieldNames'
                fn = fieldName{1};
                CVMeasuresMean.(fn) = mean(CVMeasuresAccumulator.(fn), 'omitnan');
            end


       % %%% TEXTURE
            textureMeasuresAccumulator = struct('Contrast', [], 'Correlation', [], 'Energy', [], 'Homogeneity', [], 'Entropy', [], 'Std', [], 'Mean', [], 'Range', [], ...
                'ContrastN', [], 'CorrelationN', [], 'EnergyN', [], 'HomogeneityN', [], 'EntropyN', [], 'StdN', [], 'MeanN', [], 'RangeN', [], ...
                'ContrastNB', [], 'CorrelationNB', [], 'EnergyNB', [], 'HomogeneityNB', [], 'EntropyNB', [], 'StdNB', [], 'MeanNB', [], 'RangeNB', [], 'ii', [], 'jj', []);

            for i_l = 1:size(croppedImages, 1)
                for j_l = 1:size(croppedImages, 2)
                    if ~isempty(croppedImages{i_l, j_l})
                        textureMeasures = quantifyImageTexture(croppedImages{i_l, j_l});
                        fieldNames2 = fieldnames(textureMeasures);
                        for fieldName = fieldNames2'
                            fn = fieldName{1}; % Get the field name as a string
                            textureMeasuresAccumulator.(fn)(end+1) = textureMeasures.(fn);
                        end
                        textureMeasuresAccumulator.ii(end+1) = i_l;
                        textureMeasuresAccumulator.jj(end+1) = j_l;
                    end
                end
            end

            % Calculate the mean for each field of textureMeasures
            textureMeasuresMean = struct();
            for fieldName = fieldNames2'
                fn = fieldName{1};
                textureMeasuresMean.(fn) = mean(textureMeasuresAccumulator.(fn), 'omitnan');
            end

      % %%% TEXTURE


            % Concatenate all quantification data
            rowData = {antibodyName, doseLevel, imageFileName, treatmentTime, imagingType, avgIntensityEntireIm, ...
                CVMeasuresMean.CV, CVMeasuresMean.Iso, CVMeasuresMean.Aniso, CVMeasuresMean.Theta ...
                textureMeasuresMean.Contrast, textureMeasuresMean.Correlation, textureMeasuresMean.Energy, textureMeasuresMean.Homogeneity, textureMeasuresMean.Entropy, textureMeasuresMean.Std, textureMeasuresMean.Mean, textureMeasuresMean.Range  ...
                textureMeasuresMean.ContrastN, textureMeasuresMean.CorrelationN, textureMeasuresMean.EnergyN, textureMeasuresMean.HomogeneityN, textureMeasuresMean.EntropyN, textureMeasuresMean.StdN, textureMeasuresMean.MeanN, textureMeasuresMean.RangeN  ...
                textureMeasuresMean.ContrastNB, textureMeasuresMean.CorrelationNB, textureMeasuresMean.EnergyNB, textureMeasuresMean.HomogeneityNB, textureMeasuresMean.EntropyNB, textureMeasuresMean.StdNB, textureMeasuresMean.MeanNB, textureMeasuresMean.RangeNB  ...
                circMeasures.AreaMean, circMeasures.AreaSD, circMeasures.EccentricityMean, circMeasures.EccentricitySD, circMeasures.numCircles};

           data = [data; rowData];

           gridRowData = {antibodyName, doseLevel, imageFileName, treatmentTime, imagingType, avgIntensityEntireIm, CVMeasuresAccumulator, textureMeasuresAccumulator};

           gridData = [gridData; gridRowData]; 


        end 
    end
end


% % % % % % Save


save(fullfile('/Users/amirostadi/Desktop/1o4 image analysis/AB_IM_Quantification/results','valid_DataFrame.mat'),'data');
save(fullfile('/Users/amirostadi/Desktop/1o4 image analysis/AB_IM_Quantification/results','valid_gridDataFrame.mat'),'gridData');

