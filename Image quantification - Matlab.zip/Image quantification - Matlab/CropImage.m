function croppedImages = CropImage(image)
    % Convert the input image to grayscale
    if size(image, 3) > 1
        image = rgb2gray(image);
    end

    % Initialize a mask to store the regions that are not mostly dark
    mask = false(size(image));

    % Calculate the number of regions in each dimension
    numRows = floor(size(image, 1) / 100);
    numCols = floor(size(image, 2) / 100);

    % Create a cell array to store the cropped regions
    croppedImages = cell(numRows, numCols);

    % Iterate over each region
    for r = 1:numRows
        for c = 1:numCols
            % Get the current region
            region = image((r-1)*100 + 1 : r*100, (c-1)*100 + 1 : c*100);

            % Define a threshold for darkness
            dark_threshold = .05*max(image(:));

            % Calculate the number of dark pixels
            dark_pixels_count = sum(region(:) < dark_threshold);

            % Calculate the percentage of dark pixels within this region
            total_pixels = numel(region);
            dark_pixels_percentage = (dark_pixels_count / total_pixels) * 100;
            d_P(r,c) = dark_pixels_percentage;
            % dark_pixels_percentage

            % Check if the region is not mostly dark
            if dark_pixels_percentage <= 80 
                % Store the region in the mask
                mask((r-1)*100 + 1 : r*100, (c-1)*100 + 1 : c*100) = true;

                % Store the cropped region
                croppedImages{r, c} = region;
            end
        end
    end
end



